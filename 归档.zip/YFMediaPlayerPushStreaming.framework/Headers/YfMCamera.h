//
//  YfMVideoCamera.h
//  YfMSessionCamera
//
//  Created by 张涛 on 2017/9/13.
//  Copyright © 2017年 张涛. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <UIKit/UIKit.h>


@protocol YfMCameraDelegate <NSObject>

- (void)captureOutPixelbuffer:(CVPixelBufferRef)pixelbuffer;

@end

typedef NS_ENUM(NSInteger,YfMCameraState){
    
    YfMCameraStateBack = 0,
    YfMCameraStateFront,
    
};


typedef NS_ENUM(NSInteger,YfMCameraBeautifulFilter){
    
    YfMCameraBeautifulFilterNone = 0,           //无美颜效果
    YfMCameraBeautifulFilterGlobalBeauty,       //全局美颜
    YfMCameraBeautifulFilterLocalSkinBeauty,    //局部皮肤美颜
    
};


typedef NS_ENUM(NSInteger,YfMCameraSpecialFilter){
    
    YfMCameraSpecialFilterNone = 0,         //无效果
    YfMCameraSpecialFilterBlackMagic,       //黑魔法
    YfMCameraSpecialFilterSeperaterRGB,     //色彩分离
    YfMCameraSpecialFilterBlackColorTV2,    //黑白电视
    YfMCameraSpecialFilterRightLeftMirror,  //左右镜像
    YfMCameraSpecialFilterUpdownMirror,     //上下镜像
    YfMCameraSpecialFilterFourBox,          //四宫格
    YfMCameraSpecialFilterNineBox,          //九宫格
    YfMCameraSpecialFilterSoulShake,        //灵魂出窍
    
    
    YfMCameraSpecialFilterMpegArtfacts,    //MpegArtfacts（使用的话 需要加载YFDataSource文件，不然会crash）
    
    YfMCameraSpecialFilterPolarPixellate,  //极点马赛克
    
    YfMCameraSpecialFilterPolarSketch,     //素描
    
    YfMCameraSpecialFilterAfterImage,      //残影（CPU开销较高）
    
    YfMCameraSpecialFilterBlackColorTV,    //黑白电视机（CPU开销较高）
    
    YfMCameraSpecialFilterAndroidWave,     //波浪
};


typedef NS_ENUM(NSInteger,YfMCameraStyleFilter){
    
    YfMCameraStyleFilterNone = 0,         //无效果
    YfMCameraStyleFilterVibrance,         //活力

};


typedef NS_ENUM(NSInteger,YfMCameraVisualFilter){
    
    YfMCameraVisualFilterNone = 0,         //无效果
    YfMCameraVisualFilterAmaro,            //靓丽
    YfMCameraVisualFilterRise,             //金属
    YfMCameraVisualFilterHudson,           //焦点
    YfMCameraVisualFilterXpRoll,           //深沉
    YfMCameraVisualFilterSierra,           //光束
    YfMCameraVisualFilterLomofi,           //加深
    YfMCameraVisualFilterEarlybird,        //暗黄
    YfMCameraVisualFilterSutro,            //晦暗
    YfMCameraVisualFilterToaster,          //怀旧
    YfMCameraVisualFilterBrannan,          //偏黄
    YfMCameraVisualFilterInkwell,          //黑白
    YfMCameraVisualFilterWalden,           //清新
    YfMCameraVisualFilterHefe,             //饱和
    YfMCameraVisualFilterValencia,         //偏黄
    YfMCameraVisualFilterNashville,        //夏日
    YfMCameraVisualFilter1977,             //红光
    YfMCameraVisualFilterLordkelvin,       //黄光
};


typedef NS_ENUM(NSInteger,YfMCameraOutPutImageOrientation){
    
    //以home键在屏幕哪侧为准  仅支持视图控制器为Portrait
    //normal
    YfMCameraOutPutImageOrientationPortrait = 0,         //直屏推流
    
    //即home键在屏幕右侧
    YfMCameraOutPutImageOrientationLeft,                 //左屏推流
    
    //即home键在屏幕左侧
    YfMCameraOutPutImageOrientationRight,                //右屏推流
};


@interface YfMCamera : NSObject

- (id)initWithCameraPosition:(YfMCameraState)cameraPosition outPutBufferSize:(CGSize)outPutBufferSize MetalItoolSource:( NSString *)MetalItoolSource outputImageOrientation:(YfMCameraOutPutImageOrientation)outputImageOrientation;

@property (nonatomic,weak)id<YfMCameraDelegate>delegate;

/// The AVCaptureSession used to capture from the camera
@property(readonly, retain, nonatomic) AVCaptureSession *captureSession;

/// This enables the capture session preset to be changed on the fly
@property (readonly, nonatomic, copy) NSString *captureSessionPreset;

//切换镜头
@property (nonatomic,assign)YfMCameraState cameraState;

//set camera torch
@property (nonatomic, assign) BOOL          torch;

/** Get the AVCaptureConnection of the source camera
 */
@property (readonly,strong)AVCaptureConnection *connection;

//预览层
@property (readonly,strong)UIView *preview;

//帧率设置
@property (nonatomic,assign) int32_t frameRate;

//前置摄像头是否镜像 默认开启
@property (nonatomic,assign) BOOL isMirrored;

//手动聚焦点
- (void)focusAtPoint:(CGPoint)point;

//切换镜头
- (void)rotateCamera;

//截图
- (UIImage *)snapShot;

//暂停相机
- (void)pauseCamera;

//恢复相机
- (void)resumeCamera;

//切换美颜效果
- (void)switchBeautyFilter:(YfMCameraBeautifulFilter)BeautyFilter;

//设置特效
- (void)switchSpecialFilter:(YfMCameraSpecialFilter)SpecialFilter;

//设置风格滤镜
- (void)switchStyleFilter:(YfMCameraStyleFilter)SpecialFilter;

//视觉滤镜
- (void)switchVisualFilter:(YfMCameraVisualFilter)VisualFilter;

//接收外置纹理输入。  bgra 和 yuv
- (void)receiveOutputTexture:(CVPixelBufferRef)textureBuffer display:(CGRect)displayRect;

//开启gif显示
-(void)decodeAndRenderWithFilePath:(NSString *)filePath PointRect:(CGRect)PointRect;
//关闭gif显示 && 释放
- (void)closeAndCleanGif;

//waterMask
- (void)drawImageTexture:(NSString *)filePath PointRect:(CGRect)PointRect;
//remove water mask logo
- (void)removeLogo;

//释放接口
- (void)releaseCamera;

@end
