//
//  YfConfigureManager.h
//  YfSessionCamera
//
//  Created by 张涛 on 2017/7/15.
//  Copyright © 2017年 YunFan. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface YfConfigureManager : NSObject


//配置
@property (nonatomic, readonly)NSMutableArray *ActionTextures;


//配置总数
@property (nonatomic,readonly)NSUInteger ConfigureCounts;


//使用配置
@property (nonatomic, assign)BOOL UseAble;


+ (instancetype)defaultConfigure;

//加载配置
- (BOOL)ConfigureWithConfigureChar:(const char*)ConfigureChar;


//清除配置
- (void)clean;


@end
