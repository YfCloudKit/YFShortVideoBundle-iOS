#ifndef YfMediaEditor_h
#define YfMediaEditor_h

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*PCallback)(int task_id, void* pUserData, void* pReserved);
    
//frame_type: 0->video, arg1->width, arg2->height
//frame_type: 1->audio, arg1->samplerate, arg2->channel
typedef void (*PFrameCallback)(unsigned char *data, int data_size, double pts, int arg1, int arg2, int frame_type);

//create
void YfMediaInit(PCallback cb);

// start_time: seconds
// end_time:   seconds
// return 0: success
int YfMediaSplit(const char *input_filename, const char *output_filename, double start_time, double end_time, int task_id);

int YfMediaConcat(const char *input_json, const char *output_filename, int copy_ts, int task_id);

void YfMediaMux(const char *video_filename, const char *audio_filename, const char *output_filename, int task_id);

void YfGetThumnail(const char *input_filename, const char *output_filename, int interval_secs, int task_id);

void YfReverseVideo(const char *input_filename, const char *output_filename, int task_id);
    
void YfCmdProcess(const char *cmd, PFrameCallback frame_callback, int task_id);
    
char *YfMediaGetVersion();

#ifdef __cplusplus
}  // extern "C"
#endif

#endif //YfMediaEditor_h
