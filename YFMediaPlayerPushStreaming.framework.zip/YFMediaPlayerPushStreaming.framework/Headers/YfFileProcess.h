//
//  YfFileProcess.h
//  YfFileProcess
//
//  Created by 张涛 on 2017/7/6.
//  Copyright © 2017年 张涛. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <AVFoundation/AVFoundation.h>




//0为正确
typedef void(^WritecallBack)(int flag);


typedef void (*ReadcallBack)(int type, void* pUserData, void* pReserved);

typedef NS_ENUM(NSInteger,YfFileProcessManagerInterruptType){
    
    YfFileProcessManagerInterruptTypeNone   = 0,
    YfFileProcessManagerInterruptTypeReadWrite,  
    
};

@class YfFileProcessManager;

@protocol YfFileProcessManagerDelegate <NSObject>



//输出软解码视频
- (void)willOutPutYUVTexture:(void*)yData U:(void*)uData V:(void*)vData Ysize:(size_t)Ysize Usize:(size_t)Usize Vsize:(size_t)Vsize  videoSize:(CGSize)videoSize pts:(int64_t)pts;


//输出硬解码视频数据
- (void)willOutPutYUVPixelbuffer:(CVPixelBufferRef)pixelbuffer pts:(int64_t)pts;


//开始写入
- (void)processStatusCallBackStarted:(YfFileProcessManager *)manager;

//写入完成
- (void)processStatusCallBackEnded:(YfFileProcessManager *)manager;

//写入错误
- (void)processStatusCallBackError:(YfFileProcessManager *)manager;

@end


@interface YfFileProcessManager : NSObject

@property (nonatomic,weak) id<YfFileProcessManagerDelegate>delegate;

//文件全路径 开启任务
- (void)read:(NSString *)intPutfileStr outPutFile:(NSString *)outPutPutfileStr;

//接收 已经经过特效处理后数据 （视频）
-(void)EnQueueBuffer:(CVPixelBufferRef)pixelBuffer pts:(int64_t)pts;

//销毁
- (void)clean;



//开始读取之前设置   进度条时间    进度条时间
- (void)repeat_video:(double)startSec;


//开始读取之前设置   进度条时间。  进度条时间
- (void)slow_video:(double)startSec;

@end
