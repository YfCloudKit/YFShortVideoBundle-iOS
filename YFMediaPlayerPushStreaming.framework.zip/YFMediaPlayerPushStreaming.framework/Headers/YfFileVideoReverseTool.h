//
//  YfFileVideoReverseTool.h
//  YfFileProcess
//
//  Created by 张涛 on 2017/7/12.
//  Copyright © 2017年 张涛. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

#define  FREAD_OK   0
#define  FREAD_FAILED -1
#define  F_PROCESS_OK 1


//文件加载成功
extern NSString *const YfFileVideoReverseToolLoadStatusSuccess;
//文件加载失败
extern NSString *const YfFileVideoReverseToolLoadStatusFail;

//处理进度回调
typedef void(^ProgressHandle)(CGFloat progress);

//读取状态回调
typedef void(^ReadHandle)(int flag);

typedef void(^ProcessHanlde) (int flag);



@interface YfFileVideoReverseTool : NSObject


- (instancetype)initWithInputURL:(NSURL *)InputURL;

//处理
- (void)ReversingoutputURL:(NSURL *)outputURL progressHandle:(ProgressHandle)progressHandle ProcessHanlde:(ProcessHanlde)ProcessHanlde;

//释放
- (void)clean;
@end
